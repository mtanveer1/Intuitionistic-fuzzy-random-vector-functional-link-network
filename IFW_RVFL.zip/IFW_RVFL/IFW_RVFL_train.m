function [model,train_accuracy] = IFW_RVFL_train(trainX,trainY,option)

N = option.N;
C = option.C;
S1 = option.S1;%% Intuitionistic Fuzzy weigts
S2 = option.S2;
lambda=1/C;
s = option.scale;

option.mu=option.kerfPara.pars;

A1=trainX(trainY==1,:);
B1=trainX(trainY~=1,:);
trainX=[A1;B1];
trainY=[ones(size(A1,1),1);-1*ones(size(B1,1),1)];

[Nsample,Nfea] = size(trainX);
trainY(trainY==-1)=2;
U_trainY = unique(trainY);
option.trainY=U_trainY ;
nclass = numel(U_trainY);
trainY_temp = zeros(Nsample,nclass);

% 0-1 coding for the target
for i=1:nclass
    idx = trainY==U_trainY(i);
    
    trainY_temp(idx,i) = 1;
end
rng('default')
tic
W = (rand(Nfea,N)*2*s-1);
b = s*rand(1,N);
X1 = trainX*W+repmat(b,Nsample,1);

X1 = relu(X1);
%X1 = radbas(X1);


X = [trainX,X1];

S=[S1;S2]; %trainX=[A1;B1]


if size(X,2)<Nsample
    X=diag(S)*X;
    X = [X,ones(Nsample,1)];%bias in the output layer
    beta = (eye(size(X,2))*lambda+X'*X) \ X'*(diag(S)*trainY_temp);
else
    X = [X,ones(Nsample,1)];%bias in the output layer
    StS=diag(S)*diag(S);
    Temps=StS\(eye(size(X,1))*lambda);
    beta = X'*((Temps+X*X')\trainY_temp);
end
train_time=toc;
train_time=train_time+time1;
model.beta = beta; %output weights
model.W = W; %input-hidden layer weights
model.b = b; %hidden layer bias

trainY_temp = X*beta; %output of RVFL

%softmax to generate probabilites
trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
num = exp(trainY_temp1);
dem = sum(num,2);
prob_scores = bsxfun(@rdivide,num,dem);
[max_prob,indx] = max(prob_scores,[],2);
%[~, ind_corrClass] = max(trainY,[],2);
train_accuracy = mean(indx == trainY);
model.train_time=train_time;

st = dbstack;
model.function_name= st.name;
end
%EOF