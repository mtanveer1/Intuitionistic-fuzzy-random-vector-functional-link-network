function [RVFLModel,TrainAcc,TestAcc]  = IFW_RVFL(trainX,trainY,testX,testY,option)

% Train RVFL

[RVFLModel,TrainAcc] = IFW_RVFL_train(trainX,trainY,option);

% Using trained model, predict the testing data
[TestAcc,Predict_Y] = RVFL_predict(testX,testY,RVFLModel);
Predict_Y(Predict_Y~=1)=-1;
RVFLModel.Predict_Y=Predict_Y;

end
%EOF